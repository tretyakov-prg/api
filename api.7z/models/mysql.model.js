var mysql = require('mysql2');

var conn = mysql.createConnection({
  host: process.env.HOST, // Replace with your host name
  user: process.env.USER,      // Replace with your database username
  password: process.env.PASSWORD,      // Replace with your database password
  database: process.env.DATABASE // // Replace with your database Name
}).promise();

module.exports = conn;